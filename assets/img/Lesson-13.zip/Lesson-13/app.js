// Callback hell, Promise , fetch
let container = document.querySelector(".container");
fetch("./data.json")
    .then(data => data.json())
    .then(users => {
        users.map(user => {
            container.innerHTML += `
                <div class="user-card">
                    <div class="user-card__name">${user.name}</div>
                    <div class="user-card__age">Phone: ${user.phone}</div>
                    <div class="user-card__location">Location: ${user.address.street}</div>
                </div>
            `
        })
    })

// https://restcountries.com/v3.1/all?fields=name,flags
// qr code api
// https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=


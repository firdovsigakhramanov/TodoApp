const todoInput = document.querySelector(".add-todo > input"),
    todoList = document.querySelector(".todo-app > ul");
const todos = JSON.parse(localStorage.getItem("todos")) || [];

function showTodo() {
    let li = "";
    todos.forEach((item, id) => {
        console.log(item, id);
        li += `
            <li>
                <input type="checkbox" id="todo-check" onclick="completedTodo(this,${id})"/>
                <span>${item.todoName}</span>
                <div class="todo-action">
                    <button class="btn btn-edit">
                        <i class="fa-solid fa-edit"></i>
                    </button>
                    <button class="btn btn-delete">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                </div>
            </li>
        `
        todoList.innerHTML = li
    })
}
showTodo()

function completedTodo(todoItem, todoId) {
    todoItem.nextElementSibling.classList.toggle("completed")
    todos[todoId].isCompleted = !todos[todoId].isCompleted;
    console.log(todos);
    localStorage.setItem("todos", JSON.stringify(todos))
}

todoInput.addEventListener('keyup', function (e) {
    // ul-e birdene  bos massiv kimi bax
    let taskInput = todoInput.value.trim();
    if (e.key == "Enter" && taskInput) {
        let todoItem = {
            todoName: taskInput,
            isCompleted: false,
            isEditing: false,
            isDeleted: false
        }
        todoInput.value = "";

        todos.push(todoItem)
        localStorage.setItem("todos", JSON.stringify(todos))
        console.log(todos);
        showTodo()
    }
})



























// const btn = document.querySelector(".btn"),
//     btnText = btn.querySelector("span"),
//     btnIcon = btn.querySelector("i");

// btn.addEventListener("click", function (e) {
//     console.log(e);
//     btnIcon.classList.remove("disable");
//     btnText.textContent = "Loading...";

//     setTimeout(function () {
//         btnIcon.className = "fa-solid fa-check"
//         btnText.textContent = "Finish";
//     }, 3000)
// })
